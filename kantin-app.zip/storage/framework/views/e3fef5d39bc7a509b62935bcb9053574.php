<?php $__env->startSection('title', 'Kantin'); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="mb-4">
                <h4 class="text-dark fw-semibold">
                    <i class="bi bi-shop"></i>
                    Daftar Kantin
                </h4>
            </div>
            <div class="card border-0">
                <div class="card-body">
                    <?php if(Auth::user()->role == 'admin'): ?>
                        <a href="<?php echo e(route('canteens.create-admin.view')); ?>" class="btn btn-primary mb-3 d-block col-md-2">
                            <i class="bx bx-plus"></i> Tambah Pemilik
                        </a>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <div class="alert alert-info d-inline-block" style="font-size: 13px">
                            <i class="bi bi-info-circle"></i>
                            Anda hanya dapat menambahkan pemilik kantin.
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered text-center">
                                <thead>
                                    <tr class="align-middle">
                                        <th>No.</th>
                                        <th>Nama Kantin</th>
                                        <th>Deskripsi</th>
                                        <th>Pemilik</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $canteens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canteen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="align-middle">
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($canteen->name); ?></td>
                                            <td><?php echo e($canteen->description); ?></td>
                                            <td><?php echo e($canteen->owner->name); ?></td>
                                            <td>
                                                <div class="d-flex gap-2 justify-content-center align-items-center">
                                                    <form action="<?php echo e(route('canteen.hapus', $canteen->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger">
                                                            <i class="bx bx-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="row d-flex justify-content-center align-items-center gap-5">
                            <?php $__currentLoopData = $canteens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $canteen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card p-3 mb-3 col-md-3 shadow-lg rounded-4">
                                    <div class="d-flex align-items-center justify-content-center" style="height: 200px; overflow: hidden;">
                                        <img src="<?php echo e(asset('storage/thumbnail/' . $canteen->thumbnail)); ?>" class="card-img-top img-fluid" alt="<?php echo e($canteen->name); ?> Img" style="object-fit: cover; height: 100%; width: 100%;">
                                    </div>
                                    <div class="my-3">
                                        <h5 class="card-title fw-bold"><i class="bi bi-shop"></i> <?php echo e($canteen->name); ?></h5>
                                        <p class="card-text">
                                            <?php echo e(Str::limit($canteen->description, 20)); ?>

                                        </p>
                                    </div>
                                    <div class="row d-flex justify-content-center gap-2">
                                        <a href="<?php echo e(route('canteens.show', $canteen->unique_code)); ?>"
                                            class="btn btn-outline-dark btn-sm rounded-5 col-8">
                                            Kunjungi Kantin
                                        </a>
                                        <!-- Button to trigger modal -->
                                        <button data-bs-toggle="modal" data-bs-target="#modal<?php echo e($canteen->id); ?>"
                                            class="btn btn-outline-primary btn-sm rounded-5 col-3">
                                            <i class="bi bi-info-circle"></i>
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="modal<?php echo e($canteen->id); ?>" tabindex="-1"
                                            aria-labelledby="modalLabel<?php echo e($canteen->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="modalLabel<?php echo e($canteen->id); ?>">
                                                            <?php echo e($canteen->name); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p class="fs-4"><i class="bi bi-person-check"></i> Pemilik: <?php echo e($canteen->owner->name); ?></p>
                                                        <p><?php echo e($canteen->description); ?></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/canteen/index.blade.php ENDPATH**/ ?>