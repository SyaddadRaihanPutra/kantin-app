<?php $__env->startSection('title', 'Produk Kantin'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        /* Hide the up and down arrows in number input fields */
        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
            /* Firefox */
        }
    </style>
    <section class="py-5">
        <div class="container">
            <a class="btn btn-outline-dark mb-3 btn-sm" href="<?php echo e(route('canteens.index')); ?>">
                <i class="bx bx-arrow-back"></i> Kembali </a>
            <div class="mb-4">
                <h4 class="text-dark fw-semibold"><i class="bi bi-shop"></i> Daftar Produk di
                    <?php echo e(\DB::table('canteens')->where('unique_code', Request::segment(2))->value('name')); ?>

                </h4>
            </div>
            <div class="card border-0">
                <div class="card-body">
                    <?php if(Auth::user()->role == 'admin'): ?>
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">
                            <i class="bx bx-plus"></i> Tambah Produk
                        </a>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama Produk</th>
                                        <th>Deskripsi</th>
                                        <th>Harga</th>
                                        <th>Kantin</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="align-middle">
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->description); ?></td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td><?php echo e($product->canteen->name); ?></td>
                                            <td>
                                                <div class="d-flex gap-2 align-items-center">
                                                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-light">
                                                            <i class="bx bx-trash"></i> Hapus
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="modal fade" id="invoiceModal" tabindex="-1" aria-labelledby="invoiceModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="invoiceModalLabel">Invoice <p class="fw-semibold"
                                                style="font-size: 17px"><i><u>#<?php echo e(session('id')); ?></u></i></p>
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="container">
                                            <?php if(session('success')): ?>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div
                                                            class="d-flex align-items-center justify-content-center flex-column">
                                                            <i class="bi bi-check-circle-fill text-success"
                                                                style="font-size: 60px"></i>
                                                            <h4>Transaksi Berhasil</h4>
                                                        </div>
                                                        <hr>
                                                        <p class="fw-semibold text-uppercase" style="color: #959595">
                                                            <small>Detail Produk</small>
                                                        </p>
                                                        <p class="d-flex justify-content-between">
                                                            <span><strong><?php echo e(\DB::table('products')->where('id', session('product_id'))->value('name')); ?></strong></span>
                                                            <span>Rp.
                                                                <?php echo e(number_format(\DB::table('products')->where('id', session('product_id'))->value('price'))); ?></span>
                                                        </p>
                                                        <hr>
                                                        <p><strong>Quantity:</strong> <?php echo e(session('quantity')); ?> pcs</p>
                                                        <p><strong>Total Price:</strong> Rp.
                                                            <?php echo e(number_format(session('total_price'), 0, ',', '.')); ?></p>
                                                        <p><strong>Status:</strong> <span
                                                                class="text-uppercase badge bg-warning text-dark"><?php echo e(session('status')); ?></span>
                                                        </p>
                                                        <p><strong>Order Date:</strong> <?php echo e(session('created_at')); ?></p>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <p>No order data available.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if(session('success')): ?>
                                        <div class="modal-footer">
                                            <a href="<?php echo e(route('order.share', session('id'))); ?>"
                                                class="btn btn-outline-dark btn-sm"><i class="bi bi-share"></i>
                                                &nbsp;Bagikan</a>
                                            <button type="button" class="btn btn-primary" onclick="savePrint()"><i
                                                    class="bi bi-printer"></i>
                                                &nbsp;Simpan</button>
                                            <script>
                                                function savePrint() {
                                                    const printWindow = window.open("<?php echo e(route('order.share', session('id'))); ?>", "_blank");
                                                    printWindow.addEventListener('load', function() {
                                                        printWindow.print();
                                                        printWindow.close();
                                                    }, true);
                                                }
                                            </script>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php if(session('success')): ?>
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    var invoiceModal = new bootstrap.Modal(document.getElementById('invoiceModal'), {});
                                    invoiceModal.show();
                                });
                            </script>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                        <div class="row d-flex justify-content-center align-items-center gap-5">
                            <?php if($products->count() == 0): ?>
                                <div class="col-12">
                                    <div class="alert alert-warning">Belum ada produk</div>
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card p-4 mb-3 col-12 col-sm-12 col-md-6 col-lg-3 shadow-lg rounded-4">
                                        <img src="<?php echo e(asset('storage/product/' . $product->product)); ?>" class="card-img-top"
                                            alt="<?php echo e($product->name); ?> Img"
                                            style="object-fit: contain; width: 100%; height: 150px;">
                                        <div class="my-3">
                                            <h5 class="card-title fw-semibold fs-3"><?php echo e($product->name); ?></h5>
                                            <p class="card-text"><?php echo e($product->description); ?></p>
                                            <p class="card-text fs-3 text-center">Rp.
                                                <?php echo e(number_format($product->price, 0, ',', '.')); ?>,-</p>
                                        </div>
                                        <hr>
                                        <div class="row d-flex justify-content-center gap-2">
                                            <form action="<?php echo e(route('orders.store')); ?>" method="POST" class="w-100"
                                                id="myForm">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                <input type="hidden" name="status" value="diproses">
                                                <?php $inputId = 'quantity-input-' . $loop->index; ?>
                                                <div class="input-group mb-3 d-flex justify-content-center">
                                                    <div class="d-flex">
                                                        <button class="btn btn-outline-secondary btn-sm" type="button"
                                                            onclick="decrement('<?php echo e($inputId); ?>')"
                                                            id="button-decrement-<?php echo e($loop->index); ?>">-</button>
                                                        <input type="number" name="quantity"
                                                            class="border-0 ms-2 text-center fw-semibold fs-4"
                                                            value="1" min="1" id="<?php echo e($inputId); ?>"
                                                            style="max-width: 55px;">
                                                    </div>
                                                    <div class="d-flex ms-2">
                                                        <button class="btn btn-outline-secondary btn-sm" type="button"
                                                            onclick="increment('<?php echo e($inputId); ?>')"
                                                            id="button-increment-<?php echo e($loop->index); ?>">+</button>
                                                    </div>
                                                </div>
                                                <button type="submit" onclick="confirmSubmit();" id="submit"
                                                    class="btn btn-primary rounded-5 btn-block w-100 d-block d-md-inline mt-2 mt-md-0">Pesan</button>

                                                <script>
                                                    function confirmSubmit() {
                                                        if (confirm("Apakah Anda yakin ingin mengirim pesan?")) {
                                                            var btn = document.querySelector("submit");
                                                            btn.disabled = true;

                                                            setTimeout(function() {
                                                                btn.disabled = false;
                                                            }, 5000); // Nonaktifkan selama 5 detik (5000 milidetik)

                                                            document.getElementById("myForm").submit();
                                                        }
                                                    }
                                                </script>

                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <script>
                            function increment(inputId) {
                                document.getElementById(inputId).stepUp();
                            }

                            function decrement(inputId) {
                                document.getElementById(inputId).stepDown();
                            }
                        </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/canteen/products.blade.php ENDPATH**/ ?>