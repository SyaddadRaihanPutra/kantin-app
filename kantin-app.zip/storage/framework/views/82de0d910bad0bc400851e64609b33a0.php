<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(\DB::table('canteens')->where('owner_id', Auth::user()->id)->exists()): ?>
        <section class="py-5">
            <div class="container">
                <div class="mb-4">
                    <h4 class="text-dark">Dashboard Owner</h4>
                    <p class="text-dark">Dihalaman ini anda dapat mengelola kantin yang anda miliki</p>
                </div>
                <div class="row gap-5 justify-content-center">
                    <div class="card col-12 col-md-5 rounded-5 bg-dark">
                        <div class="card-body">
                            <div class="row mb-3">
                                <h4 class="text-white fw-bold"><i class="bi bi-cash-coin fs-1"></i> &nbsp;Total Pemasukan
                                </h4>
                                <p class="text-white">Total pemasukan pada kantin anda</p>
                            </div>
                            <h1 class="text-white">Rp. <?php echo e(number_format($totalIncome, 0, ',', '.')); ?>,-</h1>
                        </div>
                    </div>
                    <div class="card col-12 col-md-5 border border-3 border-secondary rounded-5">
                        <div class="card-body">
                            <div class="row mb-3">
                                <h4 class="text-dark fw-bold"><i class="bi bi-graph-up-arrow fs-1"></i> &nbsp;Total
                                    Transaksi</h4>
                                <p class="text-dark">Total transaksi yang terjadi pada kantin anda</p>
                            </div>
                            <div class="row">
                                <div class="col d-flex align-items-center">
                                    <h1 class="text-dark mb-0"><?php echo e($totalTransaction); ?></h1>
                                    <a href="<?php echo e(route('transactions.index')); ?>"
                                        class="btn btn-outline-primary btn-sm rounded-5 ms-3">Lihat Detail</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card border-0 mt-5">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="card border-0">
                                    <div class="row mb-3">
                                        <div class="col-12 d-flex justify-content-between align-items-center">
                                            <button type="button" class="btn btn-primary btn-sm d-none d-md-block"
                                                data-bs-toggle="modal" data-bs-target="#exampleModal">
                                                Tambah Produk
                                            </button>
                                        </div>
                                        <div class="col-12 mt-3 d-block d-md-none">
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#exampleModal">
                                                Tambah Produk
                                            </button>
                                        </div>
                                    </div>
                                    <h5 class="bg-white border-0 mb-3">Produk yang dijual</h5>
                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Tambah Produk</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('products.store')); ?>" method="POST"
                                                        enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="canteen_id"
                                                            value="<?php echo e(\DB::table('canteens')->where('owner_id', Auth::user()->id)->first()->id); ?>">
                                                        <div class="mb-3">
                                                            <label for="name" class="form-label">Gambar produk</label>
                                                            <input type="file" class="form-control" id="product"
                                                                name="product" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="name" class="form-label">Nama Produk</label>
                                                            <input type="text" class="form-control" id="name"
                                                                name="name" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="name" class="form-label">Deskripsi</label>
                                                            <textarea class="form-control" id="description" name="description" required></textarea>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label for="price" class="form-label">Harga Produk</label>
                                                            <input type="number" class="form-control" id="price"
                                                                name="price" required>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary">Tambah
                                                            Produk</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if(session('success')): ?>
                                        <div role="alert" class="alert alert-success alert-dismissible">
                                            <button type="button" data-bs-dismiss="alert" aria-label="Close"
                                                class="btn-close"></button>
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div class="table-responsive">
                                        <table class="table text-nowrap text-center table-striped table-bordered">
                                            <thead>
                                                <tr class="align-middle">
                                                    <th>No.</th>
                                                    <th>Gambar</th>
                                                    <th>Nama Produk</th>
                                                    <th>Deskripsi</th>
                                                    <th>Harga</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr valign="middle">
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td>
                                                            <div class="position-relative"
                                                                style="width: 100%; padding-top: 100%;">
                                                                <img src="<?php echo e(asset('storage/product/' . $product->product)); ?>"
                                                                    class="card-img-top position-absolute top-0 start-0 w-100 h-100 shadow-sm"
                                                                    alt="<?php echo e($product->name); ?> Img"
                                                                    style="object-fit: contain;">
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($product->name); ?></td>
                                                        <td><?php echo e($product->description); ?></td>
                                                        <td>Rp. <?php echo e(number_format($product->price, 2, ',', '.')); ?></td>
                                                        <td>
                                                            <button type="button"
                                                                class="btn btn-primary btn-sm rounded-5"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#exampleModal<?php echo e($product->id); ?>">
                                                                <i class="bi bi-pencil-square"></i> </button>
                                                            <div class="modal fade" id="exampleModal<?php echo e($product->id); ?>"
                                                                tabindex="-1" aria-labelledby="exampleModalLabel"
                                                                aria-hidden="true" style="text-align: left!important">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title"
                                                                                id="exampleModalLabel">
                                                                                Edit
                                                                                Produk</h5>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <form
                                                                                action="<?php echo e(route('products.update', $product->id)); ?>"
                                                                                method="POST"
                                                                                enctype="multipart/form-data">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('PUT'); ?>
                                                                                <input type="hidden" name="canteen_id"
                                                                                    value="<?php echo e(\DB::table('canteens')->where('owner_id', Auth::user()->id)->first()->id); ?>">
                                                                                <div class="mb-3">
                                                                                    <label for="name"
                                                                                        class="form-label">Gambar
                                                                                        produk</label>
                                                                                    <input type="file"
                                                                                        class="form-control"
                                                                                        id="product" name="product"
                                                                                        required>
                                                                                </div>
                                                                                <div class="mb-3">
                                                                                    <label for="name"
                                                                                        class="form-label">Nama
                                                                                        Produk</label>
                                                                                    <input type="text"
                                                                                        class="form-control"
                                                                                        id="name" name="name"
                                                                                        value="<?php echo e($product->name); ?>"
                                                                                        required>
                                                                                </div>
                                                                                <div class="mb-3">
                                                                                    <label for="name"
                                                                                        class="form-label">Deskripsi</label>
                                                                                    <textarea class="form-control" id="description" name="description" required><?php echo e($product->description); ?></textarea>
                                                                                </div>
                                                                                <div class="mb-3">
                                                                                    <label for="price"
                                                                                        class="form-label">Harga
                                                                                        Produk</label>
                                                                                    <input type="number"
                                                                                        class="form-control"
                                                                                        id="price" name="price"
                                                                                        value="<?php echo e($product->price); ?>"
                                                                                        required
                                                                                        onkeypress="return isNumberKey(event);"
                                                                                        oninput="validateNumberInput(this);">

                                                                                    <script>
                                                                                        function isNumberKey(evt) {
                                                                                            var charCode = (evt.which) ? evt.which : evt.keyCode;
                                                                                            // Allow only numbers (0-9)
                                                                                            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                                                                                                return false;
                                                                                            }
                                                                                            return true;
                                                                                        }

                                                                                        function validateNumberInput(input) {
                                                                                            // Remove any non-numeric characters
                                                                                            input.value = input.value.replace(/[^0-9]/g, '');
                                                                                        }
                                                                                    </script>

                                                                                </div>
                                                                                <button type="submit"
                                                                                    class="btn btn-primary">Edit
                                                                                    Produk</button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>"
                                                                method="POST" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit"
                                                                    class="btn btn-danger btn-sm rounded-5"><i class="bi bi-trash"></i></button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php else: ?>
        <section class="py-5">
            <div class="container">
                <div class="mb-4">
                    <h4 class="text-dark">Buat Kantin Anda</h4>
                    <p class="text-dark">Anda belum memiliki kantin, silahkan buat kantin anda sekarang</p>
                </div>
                <div class="card border-0">
                    <div class="card-body">
                        <div class="alert alert-info" role="alert">
                            <i class="bi bi-info-circle"></i> &nbsp; <strong>Info!</strong> &nbsp; <br> <br>
                            <p>Anda belum memiliki kantin, silahkan buat kantin anda sekarang</p>
                        </div>
                        <form action="<?php echo e(route('canteens.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="owner_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="unique_code" value="<?php echo e(Str::random(10)); ?>">
                            <div class="mb-3">
                                <label for="name" class="form-label">Nama Kantin</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Deskripsi Kantin</label>
                                <textarea class="form-control" id="description" name="description" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="thumbnail" class="form-label">Foto Kantin</label>
                                <input type="file" class="form-control" id="thumbnail" name="thumbnail" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Tambah Kantin</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/pemilik/dashboard.blade.php ENDPATH**/ ?>