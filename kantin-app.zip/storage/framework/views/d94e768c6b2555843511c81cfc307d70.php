<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="mb-4">
                <h4 class="text-dark">Tambah Kantin</h4>
                
            </div>
            <div class="card border-0">
                <div class="card-body">
                    <form action="<?php echo e(route('canteens.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Kantin</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Deskripsi</label>
                            <textarea name="description" id="description" class="form-control" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="stock" class="form-label">Pemilik</label>
                            <select name="owner_id" id="owner_id" class="form-select" required>
                                <option value="" selected disabled>Pilih Pemilik</option>
                                <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($owner->id); ?>"><?php echo e($owner->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Tambah Produk</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/canteen/create.blade.php ENDPATH**/ ?>