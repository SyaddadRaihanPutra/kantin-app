<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="assets/images/logo.png" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?> | Kantin Apps</title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/boxicons/css/boxicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body class="bg-soft-blue" style="background-image: url('<?php echo e(asset('assets/images/bg-food.png')); ?>'); background-size: cover; backround-repeat: no-repeat;">
    <?php echo $__env->yieldContent('content'); ?>
    <p class="text-center text-dark">&copy; <?php echo e(now()->year); ?> by <a href="https://syaddad.pages.dev" target="_blank">syaddad.dev</a><br><small>App Version 1.0</small></p>
    <script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>