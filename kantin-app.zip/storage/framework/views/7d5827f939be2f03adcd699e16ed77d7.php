<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row align-items-center justify-content-center" style="min-height: 100vh">
            <div class="col-md-5">
                <div class="card shadow-lg m-3">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-center gap-1">
                            <img src="<?php echo e(asset('assets/images/smkn1-moto.png')); ?>" alt="logo" width="150">
                            
                        </div>
                        <p style="font-size: 13px" class="text-center mt-3">Aplikasi untuk mengelola kantin sekolah</p>
                        <hr>
                        <h5 class="text-dark fw-bold mb-4 text-center">Daftar Aplikasi</h5>
                        <form action="<?php echo e(route('register')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="role" value="pembeli">
                            <div class="mb-3">
                                <label for="email" class="mb-1">Nama Lengkap</label>
                                <?php if($errors->has('name')): ?>
                                    <div class="text-danger" role="alert">
                                        Kesalahan saat mengisi nama lengkap
                                    </div>
                                <?php endif; ?>
                                <input type="text" name="name" class="form-control"
                                    placeholder="Jhon Doe" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="mb-1">Alamat Email</label>
                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger" role="alert">
                                        Kesalahan saat mengisi alamat email
                                    </div>
                                <?php endif; ?>
                                <input type="text" name="email" class="form-control"
                                    placeholder="jhon@mail.com" required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="mb-1">Password</label>
                                <?php if($errors->has('password')): ?>
                                    <div class="text-danger" role="alert">
                                        Pastikan password kamu minimal 8 karakter
                                    </div>
                                <?php endif; ?>
                                <input type="password" name="password" class="form-control"
                                    placeholder="******" required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="mb-1">Konfirmasi Password</label>
                                <?php if($errors->has('password_confirmation')): ?>
                                    <div class="text-danger" role="alert">
                                        Pastikan password kamu sama dengan konfirmasi password
                                    </div>
                                <?php endif; ?>
                                <input type="password" name="password_confirmation" class="form-control"
                                    placeholder="******" required>
                            </div>
                            <button class="btn btn-primary d-block w-100" type="submit">Daftar</button>
                        </form>
                        <p class="pt-4 text-center">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/auth/register.blade.php ENDPATH**/ ?>