<?php $__env->startSection('title', 'History Pembelian'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="mb-4">
                <h4 class="text-dark fw-semibold"><i class="bi bi-arrow-clockwise"></i> Riwayat Pembelian</h4>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered text-center">
                            <thead>
                                <tr class="align-middle">
                                    <th>No.</th>
                                    <th>Nama Kantin</th>
                                    <th>Menu</th>
                                    <th>Jumlah</th>
                                    <th>Total Harga</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($transacts->count() == 0): ?>
                                    <tr>
                                        <td colspan="6">Belum ada data</td>
                                    </tr>
                                <?php else: ?>
                                    <?php $__currentLoopData = $transacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="align-middle">
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e(\DB::table('canteens')->where('id',\DB::table('products')->where('id', $transaction->product_id)->value('canteen_id'))->value('name')); ?>

                                            <td><?php echo e(\DB::table('products')->where('id', $transaction->product_id)->value('name')); ?>

                                            </td>
                                            <td><?php echo e($transaction->quantity); ?></td>
                                            <td>Rp<?php echo e(number_format($transaction->total_price, 0, ',', '.')); ?></td>
                                            <td class="text-uppercase">
                                                <?php if($transaction->status == 'diproses'): ?>
                                                    <span
                                                        class="badge bg-warning text-dark"><?php echo e($transaction->status); ?></span>
                                                <?php elseif($transaction->status == 'selesai'): ?>
                                                    <span class="badge bg-success"><?php echo e($transaction->status); ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?php echo e($transaction->status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/pembeli/history.blade.php ENDPATH**/ ?>