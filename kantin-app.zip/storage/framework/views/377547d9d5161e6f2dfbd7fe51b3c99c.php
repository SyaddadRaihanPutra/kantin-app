<?php $__env->startSection('title', 'List Transaksi Kantin Anda'); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="mb-4">
                <h4 class="text-dark">List Transaksi Kantin Anda</h4>
            </div>
            <div class="card border-0">
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered text-center text-nowrap">
                            <thead>
                                <tr class="align-middle">
                                    <th scope="col">No</th>
                                    <th scope="col">Nama Produk</th>
                                    <th scope="col">Harga Produk</th>
                                    <th scope="col">Jumlah</th>
                                    <th scope="col">Pembeli</th>
                                    <th scope="col">Total Pembelian</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="align-middle">
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e(\DB::table('products')->where('id', $transact->product_id)->value('name')); ?>

                                        </td>
                                        <td><?php echo e(number_format(\DB::table('products')->where('id', $transact->product_id)->value('price'),0,',','.')); ?>

                                        </td>
                                        <td><?php echo e($transact->quantity); ?> pcs</td>
                                        <td><?php echo e(\DB::table('users')->where('id', $transact->user_id)->value('name')); ?></td>
                                        <td>Rp <?php echo e(number_format($transact->total_price, 0, ',', '.')); ?></td>
                                        <td class="text-uppercase">
                                            <?php if($transact->status == 'diproses'): ?>
                                                <span class="badge bg-warning text-dark"><?php echo e($transact->status); ?></span>
                                            <?php elseif($transact->status == 'selesai'): ?>
                                                <span class="badge bg-success"><?php echo e($transact->status); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?php echo e($transact->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#detail<?php echo e($transact->id); ?>">
                                                <i class="bi bi-hourglass-split"></i>
                                            </button>
                                            <div class="modal fade" id="detail<?php echo e($transact->id); ?>" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Ubah status</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body" style="text-align: left!important">
                                                            <div class="mb-3">
                                                                <form
                                                                    action="<?php echo e(route('transactions.update', $transact->id)); ?>"
                                                                    method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PUT'); ?>
                                                                    <div class="mb-3">
                                                                        <select class="form-select form-select-sm"
                                                                            name="status" id="status">
                                                                            <option value="diproses"
                                                                                <?php echo e($transact->status == 'diproses' ? 'selected' : ''); ?>>
                                                                                Pending</option>
                                                                            <option value="selesai"
                                                                                <?php echo e($transact->status == 'selesai' ? 'selected' : ''); ?>>
                                                                                Success</option>
                                                                            <option value="dibatalkan"
                                                                                <?php echo e($transact->status == 'dibatalkan' ? 'selected' : ''); ?>>
                                                                                Cancel</option>
                                                                        </select>
                                                                    </div>
                                                                    <button type="submit"
                                                                        class="btn btn-outline-primary btn-sm col-12 rounded-5">Ubah
                                                                        status</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <form action="<?php echo e(route('transactions.destroy', $transact->id)); ?>"
                                                onsubmit="return confirm('Apakah anda yakin ingin menghapus data ini?')"
                                                method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"><i
                                                        class="bi bi-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($transacts->links()); ?>

                    <p><small>Showing <?php echo e($transacts->count()); ?> of <?php echo e($transacts->total()); ?> entries</small></p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/transactions/index.blade.php ENDPATH**/ ?>