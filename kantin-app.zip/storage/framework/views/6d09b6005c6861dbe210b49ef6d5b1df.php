<?php $__env->startSection('title', 'Pengaturan Kantin'); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="mb-4">
                <h4 class="text-dark">Pengaturan Kantin</h4>
                <p class="text-dark">Dihalaman ini anda dapat mengatur kantin anda</p>
            </div>
            <div class="card border-0">
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('settings.update', $canteen->unique_code)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="unique_code" value="<?php echo e($canteen->unique_code); ?>">
                        <input type="hidden" name="owner_id" value="<?php echo e($canteen->owner_id); ?>">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Kantin</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?php echo e(old('name', $canteen->name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?php echo e(old('description', $canteen->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="thumbnail" class="form-label">Thumbnail Kantin</label>
                            <?php if($canteen->thumbnail != null): ?>
                                <div>
                                    <img src="<?php echo e(asset('storage/thumbnail/' . $canteen->thumbnail)); ?>" alt="thumbnail" class="img-fluid mb-3 rounded-3 shadow-lg" width="250">
                                </div>
                            <?php endif; ?>
                            <input type="file" class="form-control" id="thumbnail" name="thumbnail">
                            <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/canteen/pengaturan.blade.php ENDPATH**/ ?>