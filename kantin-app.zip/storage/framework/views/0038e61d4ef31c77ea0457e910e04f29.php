<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <section class="py-5">
        <div class="container">
            <div class="mb-4">
                <h4 class="text-dark">Dashboard</h4>
                <p class="text-dark">Selamat datang di dashboard admin</p>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card border-3 border border-primary text-dark mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <i class="bx bx-store" style="font-size: 75px"></i>
                                <div>
                                    <h5 class="card-title">Total Kantin</h5>
                                    <h2 class="card-text"><?php echo e($cu); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-3 border border-primary text-dark mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <i class="bx bx-bowl-rice" style="font-size: 75px"></i>
                                <div>
                                    <h5 class="card-title">Total Produk</h5>
                                    <h2 class="card-text"><?php echo e($cp); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-3 border border-primary text-dark mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <i class="bx bx-transfer-alt" style="font-size: 75px"></i>
                                <div>
                                    <h5 class="card-title">Total Transaksi</h5>
                                    <h2 class="card-text"><?php echo e($ct); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card shadow-md text-dark mb-4">
                        <div class="card-body">
                            <h5 class="card-title"
                                style="font-size: 1.25rem; font-weight: 600; color: #000; margin-bottom: 1.25rem;">
                                Transaksi Terbaru</h5>
                            <div id="chart"></div>
                            <div class="table-responsive">
                                <table
                                    class="table table-hover text-center pe-auto text-nowrap table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Nama Produk</th>
                                            <th scope="col">Kantin</th>
                                            <th scope="col">Pembeli</th>
                                            <th scope="col">Jumlah</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $latestTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($lt->product->name); ?></td>
                                                <td><?php echo e($lt->product->canteen->name); ?></td>
                                                <td><?php echo e($lt->user->name); ?></td>
                                                <td><?php echo e($lt->quantity); ?> pcs</td>
                                                <td>Rp. <?php echo e(number_format($lt->total_price, 0, ',', '.')); ?>

                                                </td>
                                                <td><?php echo e($lt->created_at->format('d M Y H:i')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php echo e($latestTransactions->links()); ?>

                                <p><i><small>Show <?php echo e($latestTransactions->count()); ?> of <?php echo e($latestTransactions->total()); ?> transactions.</small></i></p>
                            </div>
                            <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
                            <?php
                                $products = [];
                                $canteens = [];
                                $buyers = [];
                                $quantities = [];
                                $totals = [];
                                $dates = [];

                                foreach ($latestTransactions as $lt) {
                                    $products[] = $lt->product->name;
                                    $canteens[] = $lt->product->canteen->name;
                                    $buyers[] = $lt->user->name;
                                    $quantities[] = $lt->quantity;
                                    $totals[] = $lt->total_price;
                                    $dates[] = $lt->created_at->format('d M Y H:i');
                                }
                            ?>
                            <script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    var options = {
                                        chart: {
                                            type: 'bar',
                                            height: 350
                                        },
                                        series: [{
                                            name: 'Total',
                                            data: <?php echo json_encode($totals, 15, 512) ?>
                                        }],
                                        xaxis: {
                                            categories: <?php echo json_encode($dates, 15, 512) ?>
                                        },
                                        yaxis: {
                                            title: {
                                                text: 'Total (Rp)'
                                            }
                                        },
                                    };
                                    var chart = new ApexCharts(document.querySelector("#chart"), options);
                                    chart.render();
                                });
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.lay-dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www_nginx\kantin-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>